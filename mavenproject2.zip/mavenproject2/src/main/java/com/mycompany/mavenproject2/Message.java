package com.mycompany.mavenproject2;

import java.util.Random;

public final class Message {

    private final String messageID;
    private int numMessagesSent;
    private final String recipient;
    private final String messageText;
    private String messageHash;

    private static int totalMessagesSent = 0;

    private static final java.util.ArrayList<Message> sentMessages =
            new java.util.ArrayList<>();

    public Message(String recipient, String messageText) {
        this.messageID       = generateMessageID();
        this.recipient       = recipient;
        this.messageText     = messageText;
        this.numMessagesSent = totalMessagesSent + 1;
        this.messageHash     = createMessageHash();
    }

    private String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        id.append((char) ('1' + random.nextInt(9)));
        for (int i = 1; i < 10; i++) {
            id.append((char) ('0' + random.nextInt(10)));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient == null) {
            return "Cell phone number is incorrectly formatted or does not "
                 + "contain an international code. "
                 + "Please correct the number and try again.";
        }
        boolean startsWithCode = recipient.startsWith("+");
        boolean correctLength  = recipient.length() <= 10;
        if (startsWithCode && correctLength) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not "
                 + "contain an international code. "
                 + "Please correct the number and try again.";
        }
    }

    public String createMessageHash() {
        String idPart  = messageID.substring(0, 2);
        String numPart = String.valueOf(numMessagesSent);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord  = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        String hash = idPart + ":" + numPart + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    public String sentMessage(int choice) {
        switch (choice) {
            case 1 -> {
                totalMessagesSent++;
                numMessagesSent = totalMessagesSent;
                messageHash = createMessageHash();
                sentMessages.add(this);
                return "Message successfully sent.";
            }
            case 2 -> { return "Press 0 to delete the message."; }
            case 3 -> { return "Message successfully stored."; }
            default -> { return "Invalid choice. Please select 1, 2, or 3."; }
        }
    }

    public static String validateMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over
                 + "; please reduce the size.";
        }
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\n===== ALL SENT MESSAGES =====\n");
        for (Message m : sentMessages) {
            sb.append("Message ID   : ").append(m.messageID).append("\n");
            sb.append("Message Hash : ").append(m.messageHash).append("\n");
            sb.append("Recipient    : ").append(m.recipient).append("\n");
            sb.append("Message      : ").append(m.messageText).append("\n");
            sb.append("-----------------------------\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() { return totalMessagesSent; }

    public static void resetAll() {
        totalMessagesSent = 0;
        sentMessages.clear();
    }

    public String getMessageID()       { return messageID; }
    public String getRecipient()       { return recipient; }
    public String getMessageText()     { return messageText; }
    public String getMessageHash()     { return messageHash; }
    public int    getNumMessagesSent() { return numMessagesSent; }
}