import com.mycompany.mavenproject2.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("l_w"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUserName("lolwethu"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        assertFalse(login.checkUserName("lol_wethuuuu"));
    }

    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Abcd123!"));
    }

    @Test
    public void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Abcd!!!!"));
    }

    @Test
    public void testInvalidPassword_NoCapitalLetter() {
        assertFalse(login.checkPasswordComplexity("abcd123!"));
    }

    @Test
    public void testInvalidPassword_NoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Abcd1234"));
    }

    @Test
    public void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27638633624"));
    }

    @Test
    public void testInvalidPhoneNumber_NoInternationalCode() {
        assertFalse(login.checkCellPhoneNumber("0638633624"));
    }

    @Test
    public void testInvalidPhoneNumber_WrongLength() {
        assertFalse(login.checkCellPhoneNumber("+2763863362"));
    }

    @Test
    public void testSuccessfulRegistration() {
        assertEquals("User registered successfully.",
                login.registerUser("l_w", "Abcd123!", "+27638633624"));
    }

    @Test
    public void testSuccessfulLogin() {
        login.registerUser("l_w", "Abcd123!", "+27638633624");
        assertTrue(login.loginUser("l_w", "Abcd123!"));
    }

    @Test
    public void testFailedLogin() {
        login.registerUser("l_w", "Abcd123!", "+27638633624");
        assertFalse(login.loginUser("wrongUser", "wrongPass"));
    }

    @Test
    public void testReturnLoginStatus_Success() {
        login.registerUser("l_w", "Abcd123!", "+27638633624");
        assertEquals("Welcome l_w, it is great to see you again.",
                login.returnLoginStatus(true));
    }

    @Test
    public void testReturnLoginStatus_Failure() {
        assertEquals("Username or password incorrect, please try again.",
                login.returnLoginStatus(false));
    }
}