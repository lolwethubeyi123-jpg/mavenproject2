import com.mycompany.mavenproject2.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @BeforeEach
    public void setUp() {
        Message.resetAll();
    }

    @Test
    public void testMessageLength_Success() {
        assertEquals("Message ready to send.",
                Message.validateMessageLength("Hi Mike, can you join us for dinner tonight?"));
    }

    @Test
    public void testMessageLength_Failure() {
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                Message.validateMessageLength("A".repeat(260)));
    }

    @Test
    public void testRecipientCell_Success() {
        Message msg = new Message("+2771869302", "Test message here.");
        assertEquals("Cell phone number successfully captured.",
                msg.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_Failure_NoInternationalCode() {
        Message msg = new Message("08575975889", "Test message here.");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not "
          + "contain an international code. "
          + "Please correct the number and try again.",
            msg.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_Failure_TooLong() {
        Message msg = new Message("+27718693002345", "Test message here.");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not "
          + "contain an international code. "
          + "Please correct the number and try again.",
            msg.checkRecipientCell());
    }

    @Test
    public void testMessageHash_Structure() {
        Message msg = new Message("+2771869302",
                "Hi Mike, can you join us for dinner tonight?");
        String hash = msg.getMessageHash();
        assertEquals(hash, hash.toUpperCase(), "Hash should be all uppercase");
        long colonCount = hash.chars().filter(c -> c == ':').count();
        assertEquals(2, colonCount, "Hash should contain exactly 2 colons");
        assertTrue(hash.endsWith("HITONIGHT"),
                "Hash should end with HITONIGHT");
    }

    @Test
    public void testMessageHash_CorrectWordsForTask1() {
        Message msg = new Message("+2771869302",
                "Hi Mike, can you join us for dinner tonight?");
        String hash = msg.getMessageHash();
        String wordPart = hash.substring(hash.lastIndexOf(':') + 1);
        assertEquals("HITONIGHT", wordPart);
    }

    @Test
    public void testMessageID_IsCreated() {
        Message msg = new Message("+2771869302", "Hello world.");
        assertNotNull(msg.getMessageID(), "Message ID should not be null");
    }

    @Test
    public void testMessageID_NotMoreThanTenChars() {
        Message msg = new Message("+2771869302", "Hello world.");
        assertTrue(msg.checkMessageID(),
                "Message ID should be 10 characters or fewer");
    }

    @Test
    public void testSentMessage_Send() {
        Message msg = new Message("+2771869302", "Hi Mike, joining for dinner?");
        assertEquals("Message successfully sent.", msg.sentMessage(1));
    }

    @Test
    public void testSentMessage_Disregard() {
        Message msg = new Message("+2771869302", "Hi Mike, joining for dinner?");
        assertEquals("Press 0 to delete the message.", msg.sentMessage(2));
    }

    @Test
    public void testSentMessage_Store() {
        Message msg = new Message("+2771869302", "Hi Mike, joining for dinner?");
        assertEquals("Message successfully stored.", msg.sentMessage(3));
    }

    @Test
    public void testReturnTotalMessages() {
        Message msg1 = new Message("+2771869302",
                "Hi Mike, can you join us for dinner tonight?");
        msg1.sentMessage(1);
        Message msg2 = new Message("08575975889",
                "Hi Keegan, did you receive the payment?");
        msg2.sentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void testFullFlow_Task1() {
        Message msg = new Message("+2771869302",
                "Hi Mike, can you join us for dinner tonight?");
        assertTrue(msg.checkMessageID());
        assertEquals("Cell phone number successfully captured.",
                msg.checkRecipientCell());
        assertEquals("Message successfully sent.", msg.sentMessage(1));
        assertEquals(1, Message.returnTotalMessages());
        assertTrue(msg.getMessageHash().endsWith("HITONIGHT"));
    }

    @Test
    public void testFullFlow_Task2() {
        Message msg1 = new Message("+2771869302",
                "Hi Mike, can you join us for dinner tonight?");
        msg1.sentMessage(1);
        Message msg2 = new Message("08575975889",
                "Hi Keegan, did you receive the payment?");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not "
          + "contain an international code. "
          + "Please correct the number and try again.",
            msg2.checkRecipientCell());
        assertEquals("Press 0 to delete the message.", msg2.sentMessage(2));
        assertEquals(1, Message.returnTotalMessages());
    }
}